### LinCastor release 2.4

- improvements to "do:" URLs
- do: URL will allow you to invoke menu items or focus windows

### LinCastor release 2.3

- support for MacOS 10.15

### LinCastor release 2.2

- signed with new certificate from Apple
- various bug fixes

### LinCastor release 2.1

- fixing javascript handling

### LinCastor release 2.0

WARNING: minimal Mac OS version 10.12

- compatibility for MacOS 10.14 
- support for JavaScript
- integration with LinCastor Browser
- cleaner user interface and bug fixes

### LinCastor release 1.4

- prevent handle recursions which can crash LinCastor
- pass all env variables of the LinCastor to the handler

### LinCastor release 1.3.7

- return the right AE reply if a scheme cannot be handled

This should make the OS X choose alternative handler (fixes the DropBox issue).

- fix bookmarklet field focus issue

### LinCastor release 1.3.6

WARNING: This is 10.9 build only!

## changes:

- fixes and improvements

### LinCastor release 1.3.5

## changes:

- prevent recursive handlers
- harden scheme registration
- execute shell commands in the Terminal

### LinCastor release 1.3

## changes:

- remove prefix setting
- usability changes
- scheme validation

### LinCastor release 1.2

## changes:

- register local file extensions handlers
- easier way to setup and trigger bookmarkets in a browser
- bookmarklets can also be used to injectjavascript from a handler
- fixed the filter

### LinCastor release 1.1

## changes:

- support linplugins

### LinCastor release 0.8.6 BETA

## changes:

- small UI changes
- support libraries update

### LinCastor release 0.8.5 BETA

## changes:

- error log

## changes:

- built-in HTTP server
- handling URL requests via HTTP protocol

### LinCastor release 0.8 BETA

## changes:

- support axtalk protocol
- support 'invalid' URL such as message:<xxx>
- the <xxx> will be passed as URL_VALUE

### LinCastor release 0.7 BETA

## changes:

- support for growl
- compile applescripts on demand
- various UI fixes

### LinCastor release 0.6 BETA

## changes:

- initial beta
